module.exports.orm = {
  _hookTimeout: 100000 // I used 60 seconds as my new timeout
};