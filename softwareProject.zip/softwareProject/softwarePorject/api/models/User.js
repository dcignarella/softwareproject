/**
 * User.js
 *
 * @description :: TODO: You might write a short summary of how this model works and what it represents here.
 * @docs        :: http://sailsjs.org/documentation/concepts/models-and-orm/models
 */

module.exports = {

    schema: true,
  attributes: {
      fName:{
          type: 'string',
          required: 'true',
          alpha: 'true'
      },
      lName:{
          type: 'string',
          required: 'true',
          alpha: 'true'
      },
      address1:{
          type: 'string',
          required: 'true'
      },
      address2:{
          type: 'string'
      },
      city:{
          type: 'string',
          required: 'true',
          alpha: 'true'
      },
      state:{
          type: 'string',
          required: 'true'
      },
      zip:{
          type: 'integer',
          required: 'true'
      },
      clientLink:{
          collection: 'client',
          via: 'userClientLink'
      },
      doctorLink:{
          collection: 'doctor',
          via: 'userDoctorLink'
      },
      typeLink:{
          collection: 'type',
          via: 'userTypeLink'
      },
      loginInfoLink:{
          collection: 'loginInfo',
          via: 'userLoginInfoLink'
      },
      validationMessages:{
          fName:{
              required: 'first name field left blank',
              alpha: 'first name field can only have letters'
          },
          lName:{
              required: 'last name field left blank',
              alpha: 'last name field can only have letters'
          },
          address1:{
              required: 'first address line left blank'
          },
          city:{
              required: 'city field left blank',
              alpha: 'city can only contain letters'
          },
          state:{
              required: 'state field left blank'
          },
          zip:{
              type: 'zip field can only have numbers',
              required: 'zip field left blank'
          }
          
      }
  }
};

