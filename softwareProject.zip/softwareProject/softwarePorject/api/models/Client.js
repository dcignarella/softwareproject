/**
 * Client.js
 *
 * @description :: TODO: You might write a short summary of how this model works and what it represents here.
 * @docs        :: http://sailsjs.org/documentation/concepts/models-and-orm/models
 */

module.exports = {
schema: true,
  attributes: {
      age:{
          type: 'integer',
          required: 'true'
      },
      gender:{
          type: 'string',
          required: 'true'
      },
      eContactFName:{
          type: 'string',
          required: 'true'
      },
      eContactLName:{
          type: 'string',
          required: 'true'
      },
      eContactPhoneNumber:{
          type: 'integer',
          required: 'true'
      },
      userClientLink:{
          model: 'user'
      },
      appointmentLink:{
          collection: 'appointment',
          via: 'clientAppointmentLink'
      }
  }
};

