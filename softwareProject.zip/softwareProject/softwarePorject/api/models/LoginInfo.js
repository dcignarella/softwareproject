/**
 * LoginInfo.js
 *
 * @description :: TODO: You might write a short summary of how this model works and what it represents here.
 * @docs        :: http://sailsjs.org/documentation/concepts/models-and-orm/models
 */

module.exports = {
schema: true,
  attributes: {
      phone:{
          type:'integer',
          required:'true',
          minLength: '10',
          maxLength: '10'
      },
      email:{
          type:'email',
          required:'true',
          unique:'true',
      },
      password:{
          type:'string',
          required:'true',
          alphanumeric: 'true',
          minLength:'8'
      },
      userLoginInfoLink:{
          model:'user'
      },
      validationMessages:{
          phone:{
              required: 'phone number field left blank',
              type: 'phone field only contains integers',
              minLength: 'phone number only has 10 digets',
              maxLength: '10 digets are in a phone number only'
          },
          email:{
              required: 'email required for log in',
              type: 'not a valid email',
              unique: 'this email exists already'
          },
          password:{
              required: 'password needed for log in'
          }
          
      }
  }
};

