module.exports = function(req,res,next){
    //create blank object
    res.locals.flash = {};
    if(!req.session.flash) return next();
    //if req.sessions.flash exists, create copy
    res.locals.flash = _.clone(req.session.flash);
    //clears flash
    req.session.flash = {};
    next();
};