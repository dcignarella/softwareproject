/**
 * DoctorController
 *
 * @description :: Server-side logic for managing doctors
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	new: function(req,res,next){
        console.log(req.param('startAvail'+"= date here"));
        var startArr = req.param('startAvail').split(':');
        var endArr = req.param('endAvail').split(':');
        var startAvailTime = new Array(1);
        var endAvailTime = new Array(1);
        var i;
        for (i=0;i<=1;i++){
            startAvailTime[i] = parseInt(startArr[i]);
            endAvailTime[i] = parseInt(endArr[i]);
        }
        var start= new Date(1,1,1,startAvailTime[0],startAvailTime[1]);
        var end = new Date(1,1,1,endAvailTime[0],endAvailTime[1]);
        User.findOne({id: req.param('id')}).exec(function (err, user){
                if (err) {
                    req.session.flash = {
                        err: err
                    }
                }
            Type.create({ 
                detail: 'doctor',
                userTypeLink: user.id}, function TypeCreate (err, type){
                    if (err){
                        req.session.flash = {
                            err: err
                        }
                    }
                Doctor.create({
                    title: req.param('title'),
                    startAvail: start,
                    endAvail: end,
                    userDoctorLink: user.id}, function DoctorCreate(err, client){
                        if (err){
                            Type.destroy(type.id, function(err){
                                req.flash('message','a problem occured with the creation of the doctor information, double check inputs and try again');
                                return res.redirect('/user/createCD/'+user.id);
                            });
                        }
                        else{
                            res.redirect('/user/profile/'+user.id);
                        }
                    });
            });
        });
    },
    
    edit:  function(req,res,next){
        var tvalueA1=0;
        var loopThru=true;
        for (var i = 0; i<req.param('address1').length;i++){
            var chara = req.param('address1').charAt(i);    
            if ((chara>='a' && chara<='z')||(chara>='A' && chara<='Z')||(chara>='0' && chara <='9')||(chara===' ')){;}
            else{
                req.flash('message','a problem occured with the creation of the user profile, double check inputs and try again');
                return res.redirect('/user/create');
                i=100;
            }
        }
        if (typeof req.param('address2')!= 'undefined'){
            for (var j=0; j<req.param('address2').length;j++){
                var chara = req.param('address2').charAt(j);    
                if ((chara>='a' && chara<='z')||(chara>='A' && chara<='Z')||(chara>='0' && chara <='9')||(chara===' ')){;}
                else{
                    req.flash('message','a problem occured with the creation of the user profile, double check inputs and try again');
                    return res.redirect('/user/create');
                    j=100;
                }
            }
        }
        if ((i=req.param('address1').length) && (j=req.param('address2').length)){tvalueA1=1;}
        if (tvalueA1=1){
            var startArr = req.param('startAvail').split(':');
            var endArr = req.param('endAvail').split(':');
            var startAvailTime = new Array(1);
            var endAvailTime = new Array(1);
            var i;
            for (i=0;i<=1;i++){
                startAvailTime[i] = parseInt(startArr[i]);
                endAvailTime[i] = parseInt(endArr[i]);
            }
            var start= new Date(1,1,1,startAvailTime[0],startAvailTime[1]);
            var end = new Date(1,1,1,endAvailTime[0],endAvailTime[1]);
            User.findOne({id: req.param('userId')}).exec(function(err,user){
                LoginInfo.findOne({id: req.param('infoId')}).exec(function(err,info){
                    Doctor.findOne({id: req.param('doctorId')}).exec(function(err,doctor){
                        var oldFName = user.fName;
                        var oldLName = user.lName;
                        var oldAddress1 = user.address1;
                        var oldAddress2 = user.address2;
                        var oldCity = user.city;
                        var oldState = user.state;
                        var oldZip = user.zip;
                        var oldEmail = info.email;
                        var oldPhone = info.phone;
                        var oldPassword = info.password;
                        var oldTitle = doctor.title;
                        var oldStart = doctor.startAvail;
                        var oldEnd = doctor.endAvail;
                        User.update(req.param('userId'), {
                                fName: req.param('fName'),
                                lName: req.param('lName'),
                                address1: req.param('address1'), 
                                address2: req.param('address2'),
                                city: req.param('city'),
                                state: req.param('state'), 
                                zip: req.param('zip')
                            }, function userUpdated (err1){
                                if (err1){                    
                                    req.flash('message','an error occured when editing user information, double check inputs and try again');
                                    return res.redirect('/type/edit/'+user.id);
                                }
                                LoginInfo.update(req.param('infoId'),{
                                    phone: req.param('phone'),
                                    email: req.param('email'),
                                    password: req.param('password')
                                }, function loginInfoUpdated (err2, newInfo){
                                   if (err2){
                                        console.log("made it");
                                       User.update(req.param('userId'), {
                                            fName: oldFName,
                                            lName: oldLName,
                                            address1: oldAddress1, 
                                            address2: oldAddress2,
                                            city: oldCity,
                                            state: oldState, 
                                            zip: oldZip
                                        }, function userUpdated (err1, oldUser){
                                            req.flash('message','an error occured when editing login information, double check inputs and try again');
                                            return res.redirect('/type/edit/'+user.id);
                                       });
                                   }
                                    else{
                                        Doctor.update(req.param('doctorId'),{
                                            title: req.param('title'),
                                            startAvail: start,
                                            endAvail: end
                                        }, function clientUpdated (err3, newDoctor){
                                            if (err3){

                                                User.update(req.param('userId'), {
                                                    fName: oldFName,
                                                    lName: oldLName,
                                                    address1: oldAddress1, 
                                                    address2: oldAddress2,
                                                    city: oldCity,
                                                    state: oldState, 
                                                    zip: oldZip
                                                }, function userUpdated (err1){
                                                    LoginInfo.update(req.param('infoId'),{
                                                        phone: oldPhone,
                                                        email: oldEmail,
                                                        password: oldPassword
                                                    }, function loginInfoUpdated (err2){
                                                        req.flash('message','an error occured when editing doctor information, double check inputs and try again');
                                                        return res.redirect('/type/edit/'+user.id);

                                                    });
                                                });
                                            }
                                            else{
                                                res.redirect('/user/profile/'+req.param('userId'));
                                            }

                                        });
                                    }
                                });
                            });
                        });
                    });
                });
            }
        
            
    },
    
    doctorSearch: function(req, res, next){
        if ((req.param('search'))!=""){
            Doctor.find({title: req.param('search')}).exec(function(err, doctors){
                if (err) {res.serverError(err);}
                if (doctors.length===0) {return res.view('client/noDoctor.ejs');}
                var idList = new Array(doctors.length-1);
                var i = 0;
                for(i=0;i<=doctors.length-1;i++){
                    idList.push(doctors[i].userDoctorLink);
                }
                User.find().where({id:idList}).exec(function(err, users){
                    if (err) {res.serverError(err);}
                    console.log(users);
                    res.view('client/clientResult.ejs',{
                        user: users,
                        doctor: doctors,
                        idPass: req.param('id')
                    });
                });
            });
        }
        else{
            res.view('client/clientNone.ejs');
        }
    }
};

