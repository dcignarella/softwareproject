/**
 * TypeController
 *
 * @description :: Server-side logic for managing types
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
    view: function(req,res,next){
        User.findOne({id: req.param('id')}).exec(function (err, user){
            if (typeof req.param('clientDoctor')!= 'undefined'){
                if(req.param('clientDoctor').charAt(0)==='1'){
                    res.view('type/client.ejs',{
                        user: user
                    });
                }
                else if(req.param('clientDoctor').charAt(0)==='0'){
                    res.view('type/doctor.ejs',{
                        user: user
                    });
                }
            }
            else{
                res.view('type/none.ejs');
            }
        });
    },
    
    edit: function(req,res,next){
        User.findOne({id: req.param('id')}).exec(function (err, user){
            LoginInfo.findOne({userLoginInfoLink: user.id}).exec(function(err, info){
                Type.findOne({userTypeLink: user.id}).exec(function(err, typeMain){
                    if(typeMain.detail.includes("client")){
                        Client.findOne({userClientLink: user.id}).exec(function(err, client){
                            res.view('client/clientEdit.ejs',{
                                user: user,
                                client: client,
                                info: info
                            });
                        });
                    }
                    else{
                        Doctor.findOne({userDoctorLink: user.id}).exec(function(err, doctor){
                            res.view('doctor/doctorEdit.ejs',{
                                user: user,
                                doctor: doctor,
                                timeHStart: doctor.startAvail.getHours(),
                                timeMStart: doctor.startAvail.getMinutes(),
                                timeHEnd: doctor.endAvail.getHours(),
                                timeMEnd: doctor.endAvail.getMinutes(),
                                info: info
                            });
                        });
                    }
                });
            });
        });
    }
};

