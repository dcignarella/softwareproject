/**
 * SessionController
 *
 * @description :: Server-side logic for managing sessions
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
    'new': function(req, res){
        res.view('session/new.ejs');
    },
    create: function(req,res,next){
        if (!req.param('email') || (!req.param('password'))){
            req.flash('message','you need both a username and a password to log in');
            return res.redirect('/session/new');
        }
        LoginInfo.findOne({email: req.param('email')}).exec(function foundUser(err,userInfo){
            if(err){
                req.flash('message','an error occured please try again');
                return res.redirect('/session/new');
            }
            else if(!userInfo){
                req.flash('message','the email is not attached to a user, please create an account');
                return res.redirect('/session/new');
            }
            else{
                console.log(userInfo);
                if(userInfo.password===req.param('password')){
                    User.findOne({id: userInfo.userLoginInfoLink}).exec(function(err, user){
                        if(user){
                            Type.findOne({userTypeLink: user.id}).exec(function(err, typeInfo){
                                if(!typeInfo){
                                    req.session.authenticated = true;
                                    req.session.User = user;
                                    
                                    req.flash('message','the profile was not finished being made, please complete it');
                                    return res.redirect('/user/createCD/'+user.id);
                                }
                                else{
                                    req.session.authenticated = true;
                                    req.session.User = user;

                                    return res.redirect('/user/profile/'+user.id);
                                }
                            });
                        }
                        else{
                            req.flash('message','an error occured, please try again');
                            return res.redirect('/session/new');
                        }
                    });
                }
                else{
                    req.flash('message','the email and password do not match, please try again');
                    return res.redirect('/session/new');
                }
            }
        });
    },
    
    delete: function(req,res,next){
        req.session.destroy();
        return res.redirect('/session/new');
        
    }
};

