/**
 * ClientController
 *
 * @description :: Server-side logic for managing clients
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	new: function(req,res,next){
        User.findOne({id: req.param('id')}).exec(function (err, user){
                if (err) {
                    req.session.flash = {
                        err: err
                    }
                }
            Type.create({ 
                detail: 'client',
                userTypeLink: user.id}, function TypeCreate (err, type){
                    if (err){
                        req.session.flash = {
                            err: err
                        }
                    }
                Client.create({
                    age: req.param('age'),
                    gender: req.param('gender'),
                    eContactFName: req.param('eContactFName'), 
                    eContactLName: req.param('eContactLName'),
                    eContactPhoneNumber: req.param('eContactPhoneNumber'),
                    userClientLink: user.id}, function ClientCreate(err, client){
                        if (err){
                            Type.destroy(type.id, function(err){
                                req.flash('message','a problem occured with the creation of the client information, double check inputs and try again');
                                return res.redirect('/user/createCD/'+user.id);
                            });
                        }
                        else{
                            res.redirect('/user/profile/'+user.id);
                        }
                    });
            });
        });
    },
    
    edit:  function(req,res,next){
        var tvalueA1=0;
        var loopThru=true;
        var validator = require('sails-custom-validation-messages');
        for (var i = 0; i<req.param('address1').length;i++){
            var chara = req.param('address1').charAt(i);    
            if ((chara>='a' && chara<='z')||(chara>='A' && chara<='Z')||(chara>='0' && chara <='9')||(chara===' ')){;}
            else{
                req.flash('message','a problem occured with the creation of the user profile, double check inputs and try again');
                return res.redirect('/user/create');
                i=100;
            }
        }
        if (typeof req.param('address2')!= 'undefined'){
            for (var j=0; j<req.param('address2').length;j++){
                var chara = req.param('address2').charAt(j);    
                if ((chara>='a' && chara<='z')||(chara>='A' && chara<='Z')||(chara>='0' && chara <='9')||(chara===' ')){;}
                else{
                    req.flash('message','a problem occured with the creation of the user profile, double check inputs and try again');
                    return res.redirect('/user/create');
                    j=100;
                }
            }
        }
        if ((i=req.param('address1').length) && (j=req.param('address2').length)){tvalueA1=1;}
        if (tvalueA1=1){
            User.findOne({id: req.param('userId')}).exec(function(err,user){
                LoginInfo.findOne({id: req.param('infoId')}).exec(function(err,info){
                    Client.findOne({id: req.param('clientId')}).exec(function(err,client){
                        var oldFName = user.fName;
                        var oldLName = user.lName;
                        var oldAddress1 = user.address1;
                        var oldAddress2 = user.address2;
                        var oldCity = user.city;
                        var oldState = user.state;
                        var oldZip = user.zip;
                        var oldEmail = info.email;
                        var oldPhone = info.phone;
                        var oldPassword = info.password;
                        var oldAge = client.age;
                        var oldGender = client.gender;
                        var oldEContactFName = client.eContactFName;
                        var oldEContactLName = client.eContactLName;
                        var oldEContactPhoneNumber = client.eContactPhoneNumber;
                        User.update(req.param('userId'), {
                                fName: req.param('fName'),
                                lName: req.param('lName'),
                                address1: req.param('address1'), 
                                address2: req.param('address2'),
                                city: req.param('city'),
                                state: req.param('state'), 
                                zip: req.param('zip')
                            }, function userUpdated (err1){
                                if (err1){                    
                                    req.flash('message','an error occured when editing user information, double check inputs and try again');
                                    return res.redirect('/type/edit/'+user.id);
                                }
                                LoginInfo.update(req.param('infoId'),{
                                    phone: req.param('phone'),
                                    email: req.param('email'),
                                    password: req.param('password')
                                }, function loginInfoUpdated (err2, newInfo){
                                   if (err2){
                                        console.log("made it");
                                       User.update(req.param('userId'), {
                                            fName: oldFName,
                                            lName: oldLName,
                                            address1: oldAddress1, 
                                            address2: oldAddress2,
                                            city: oldCity,
                                            state: oldState, 
                                            zip: oldZip
                                        }, function userUpdated (err1, oldUser){
                                            req.flash('message','an error occured when editing login information, double check inputs and try again');
                                            return res.redirect('/type/edit/'+user.id);
                                       });
                                   }
                                    else{
                                        Client.update(req.param('clientId'),{
                                            age: req.param("age"),
                                            gender: req.param("gender"),
                                            eContactFName: req.param("eContactFName"),
                                            eContactLName: req.param("eContactLName"),
                                            eContactPhoneNumber: req.param("eContactPhoneNumber")
                                        }, function clientUpdated (err3, newClient){
                                            if (err3){

                                                User.update(req.param('userId'), {
                                                    fName: oldFName,
                                                    lName: oldLName,
                                                    address1: oldAddress1, 
                                                    address2: oldAddress2,
                                                    city: oldCity,
                                                    state: oldState, 
                                                    zip: oldZip
                                                }, function userUpdated (err1){
                                                    LoginInfo.update(req.param('infoId'),{
                                                        phone: oldPhone,
                                                        email: oldEmail,
                                                        password: oldPassword
                                                    }, function loginInfoUpdated (err2){
                                                        req.flash('message','an error occured when editing client information, double check inputs and try again');
                                                        return res.redirect('/type/edit/'+user.id);

                                                    });
                                                });
                                            }
                                            else{
                                                res.redirect('/user/profile/'+req.param('userId'));
                                            }

                                        });
                                    }
                                });
                            });
                        });
                    });
                });
            }
        
            
    },
//        User.update(req.param('userId'), {
//            fName: req.param('fName'),
//            lName: req.param('lName'),
//            address1: req.param('address1'), 
//            address2: req.param('address2'),
//            city: req.param('city'),
//            state: req.param('state'), 
//            zip: req.param('zip')
//        }, function userUpdated (err){
//            if (err){}
//            LoginInfo.update(req.param('infoId'),{
//                phone: req.param('phone'),
//                email: req.param('email'),
//                password: req.param('password')
//            }, function loginInfoUpdated (err){
//               if (err){}
//                Client.update(req.param('clientId'),{  
//                    age: req.param('age'),
//                    gender: req.param('gender'),
//                    eContactFName: req.param('eContactFName'), 
//                    eContactLName: req.param('eContactLName'),
//                    eContactPhoneNumber: req.param('eContactPhoneNumber')
//                }, function clientUpdated (err){
//                    if (err){}
//                    res.redirect('/user/profile/'+req.param('userId'));
//                });
//            });
//        });
//    },
    
};

