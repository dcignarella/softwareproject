/**
 * AppointmentController
 *
 * @description :: Server-side logic for managing appointments
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	create: function(req,res,next){
        //finds one record takes passed id and check if user exists, if not return error, if so show it
        User.findOne({id: req.param('idDoctor')}).exec(function foundClient(err,doctor){
            if(err) {return res.serverError(err);}
            Doctor.findOne({userDoctorLink: doctor.id}).exec(function(err,doctorInfo){
                if(err) {return res.serverError(err);}
                User.findOne({id: req.param('idClient')}).exec(function foundClient(err,client){
                    if(err) {return res.serverError(err);}
                    res.view({
                        doctor: doctor,
                        client: client,
                        doctorInfo: doctorInfo
                    });
                });
            });
        });
    },
    
    new: function(req,res,next){
        var appointDateArr = req.param('appointDate').split('-');
        var appointTimeArr = req.param('appointTime').split(':');
        var appointAvailDate = new Array(2);
        var appointAvailTime = new Array(1);
        var currentDay = new Date();
        currentDay.setDate(currentDay.getDate()+7);
        var i;
        for (i=0;i<=1;i++){
            appointAvailTime[i] = parseInt(appointTimeArr[i]);
        }
        for (i=0;i<=2;i++){
            appointAvailDate[i] = parseInt(appointDateArr[i]);
        }
        var newDateTime= new Date(appointAvailDate[0],appointAvailDate[1]-1,appointAvailDate[2],appointAvailTime[0],appointAvailTime[1])
        User.findOne({id:req.param('idClient')}).exec(function (err,client){
            Client.findOne({userClientLink:client.id}).exec(function (err,clientInfo){
               User.findOne({id:req.param('idDoctor')}).exec(function (err,doctor){
                    Doctor.findOne({userDoctorLink:doctor.id}).exec(function (err,doctorInfo){
                        if ((newDateTime.getHours()>=doctorInfo.startAvail.getHours()) && (newDateTime.getHours()<=doctorInfo.endAvail.getHours()) && (newDateTime.getMinutes()>=doctorInfo.startAvail.getMinutes()) && (newDateTime.getMinutes()<=doctorInfo.endAvail.getMinutes())){
                            if (newDateTime>=currentDay){
                                Appointment.create({
                                    setDateTime: newDateTime,
                                    reason: req.param('reason'),
                                    doctorAppointmentLink: doctorInfo.id,
                                    clientAppointmentLink: clientInfo.id}).exec(function createAppointment(err,appointment){
                                    if (err){
                                        req.flash('message','the appointment cannot be made at this time, double check inputs and try again');
                                        Type.findOne({userTypeLink: client.id}).exec(function (err, typeMain){
                                            return res.redirect('/user/profile/'+client.id); 
                                        });
                                    }
                                    else{
                                        //get client appointment list
                                        Appointment.find().where({clientAppointmentLink: clientInfo.id}).exec(function(err,appointList){
                                            var doubleBookClient=1;
                                            var twoAppointments = 1;
                                            for(i=0;i<appointList.length-1;i++){
                                                
                                                if(appointList[i].setDateTime.getTime()===appointment.setDateTime.getTime()){
                                                    doubleBookClient=0;
                                                }
                                                if(appointList[i].doctorAppointmentLink===appointment.doctorAppointmentLink){
                                                    twoAppointments=0;
                                                }
                                                
                                            }
                                            if(i===appointList.length-1){
                                                if (doubleBookClient===0){
                                                    req.flash('message','appointment already exists in this spot, double check inputs and try again');
                                                    Appointment.destroy(appointment.id, function(err){
                                                        res.redirect('/user/profile/'+client.id); 
                                                    });
                                                }
                                                else if(twoAppointments===0){
                                                    req.flash('message','you already made an appointment with this doctor, double check inputs and try again');
                                                    Appointment.destroy(appointment.id, function(err){
                                                        res.redirect('/user/profile/'+client.id); 
                                                    });
                                                }
                                                else{
                                                    Appointment.find().where({doctorAppointmentLink: doctorInfo.id}).exec(function(err,doctorAppointList){
                                                        var doubleBookDoctor=1;
                                                        for(i=0;i<doctorAppointList.length-1;i++){
                                                            
                                                            if(doctorAppointList[i].setDateTime.getTime()===appointment.setDateTime.getTime()){
                                                                doubleBookDoctor=0;
                                                            }

                                                        }
                                                        
                                                        if(i===doctorAppointList.length-1){
                                                            
                                                            if (doubleBookDoctor===0){
                                                                
                                                                req.flash('message','doctor already has an appointment then, double check inputs and try again');
                                                                Appointment.destroy(appointment.id, function(err){
                                                                    res.redirect('/user/profile/'+client.id); 
                                                                });
                                                            }
                                                            else{
                                                                Type.findOne({userTypeLink: client.id}).exec(function (err, typeMain){
                                                                    return res.redirect('/user/profile/'+client.id); 
                                                                });
                                                            }
                                                        }
                                                    });    
                                                }
                                            }
                                        });
                                    }
                                });
                            }
                            else{
                                req.flash('message','the appointment cannot be made that early');
                                return res.redirect('/user/profile/'+client.id);
                            }
                        }
                        else{
                            req.flash('message','the appointment cannot be made outside of the availibility time of the doctor, double check inputs and try again');
                            return res.redirect('/user/profile/'+client.id);
                        }
                        
                    }); 
                });
            });
        });
    },
    
    search: function(req,res,next){
        User.findOne({id: req.param('id')}).exec(function (err,user){
            if(req.param('userType').includes('client')){
                Client.findOne({userClientLink: user.id}).exec(function (err,client){
                    Appointment.find({clientAppointmentLink: client.id}).exec(function(err,appointments){
                        if (appointments.length===0){return res.view('appointment/none.ejs');}
                        var idList = new Array(appointments.length-1);
                        var i;
                        for(i=0;i<=appointments.length-1;i++){
                            idList.push(appointments[i].doctorAppointmentLink);
                        }
                        Doctor.find().where({id:idList}).exec(function(err, doctors){
                            var userIDList = new Array(doctors.length-1);
                            var i;
                            for(i=0;i<=doctors.length-1;i++){
                                userIDList.push(doctors[i].userDoctorLink); 
                            }
                            User.find().where({id:userIDList}).exec(function(err,users){
                                console.log(users.doctorLink);
                                res.view('appointment/viewDoctors.ejs',{
                                    doctors: doctors,
                                    appointments: appointments,
                                    users: users,
                                    user:user
                                });
                            });
                        });
                    });
                });
            }
            else{
                Doctor.findOne({userDoctorLink: user.id}).exec(function (err,doctor){
                    Appointment.find({doctorAppointmentLink: doctor.id}).exec(function(err,appointments){
                        if (appointments.length===0){return res.view('appointment/none.ejs');}
                        var idList = new Array(appointments.length-1);
                        var i;
                        for(i=0;i<=appointments.length-1;i++){
                            idList.push(appointments[i].clientAppointmentLink);
                        }
                        Client.find().where({id:idList}).exec(function(err,clients){
                            var userIDList = new Array(clients.length-1);
                            var i;
                            for(i=0;i<=clients.length-1;i++){
                                userIDList.push(clients[i].userClientLink);
                            }
                            User.find().where({id:userIDList}).exec(function(err,users){
                                console.log(users);
                                res.view('appointment/viewClients.ejs',{
                                    users: users,
                                    clients: clients,
                                    appointments: appointments,
                                    user: user//,
                                    //AppTimeHours: appointments.setDateTime.getHours(),
                                    //AppTimeMinutes: appointments.setDateTime.getMinutes(),
                                    //AppDateYear: appointments.setDateTime.getFullYear(),
                                    //AppDateMonth: appointments.setDateTime.getMonth()+1,
                                    //AppDateDay: appointments.setDateTime.getDay()
                                });
                            });
                        });
                    });
                });
            }
        });
    },
    
    viewDoctorAppointment: function(req, res, next){
        Appointment.findOne({id: req.param('id')}).exec(function(err,appointment){
            Doctor.findOne({id: appointment.doctorAppointmentLink}).exec(function(err, doctor){
                User.findOne({id:doctor.userDoctorLink}).exec(function(err,user){
                    res.view('appointment/viewDoctorAppointment.ejs',{
                        doctor: doctor,
                        appointment: appointment,
                        user: user,
                        userMain: req.param("idUser")
                    });
                });
            });
        });    
    },
    
    viewClientAppointment: function(req, res, next){
        Appointment.findOne({id: req.param('id')}).exec(function(err,appointment){
            Client.findOne({id: appointment.clientAppointmentLink}).exec(function(err, client){
                User.findOne({id:client.userClientLink}).exec(function(err,user){
                    res.view({
                        client: client,
                        appointment: appointment,
                        user: user
                    });
                });
            });
        });    
    },
    
    deleteConfirm: function(req,res,next){
        Appointment.findOne({id: req.param('id')}).exec(function(err,appointment){
            Client.findOne({id: appointment.clientAppointmentLink}).exec(function(err, client){
                User.findOne({id:client.userClientLink}).exec(function(err,user){
                    res.view('appointment/deleteConfirm.ejs',{
                        appointment: appointment,
                        user: user
                    });
                });
            });
        });
    },
    
    delete: function(req, res, next){
        Appointment.findOne({id: req.param('id')}).exec(function(err,appointment){
            Client.findOne({id: appointment.clientAppointmentLink}).exec(function(err, client){
                User.findOne({id:client.userClientLink}).exec(function(err,user){
                    Appointment.destroy(appointment.id, function(err){
                        res.redirect('/user/profile/'+user.id); 
                    });
                });
            });
        });    
    }
};

