/**
 * UserController
 *
 * @description :: Server-side logic for managing users
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	'create': function(req, res){
        res.view('user/create.ejs');
    }, 
    
    new: function(req,res,next){
        var tvalueA1=0;
        var loopThru=true;
        var validator = require('sails-custom-validation-messages');
        for (var i = 0; i<req.param('address1').length;i++){
            var chara = req.param('address1').charAt(i);    
            if ((chara>='a' && chara<='z')||(chara>='A' && chara<='Z')||(chara>='0' && chara <='9')||(chara===' ')){;}
            else{
                req.flash('message','a problem occured with the creation of the user profile, double check inputs and try again');
                return res.redirect('/user/create');
                i=100;
            }
        }
        if (typeof req.param('address2')!= 'undefined'){
            for (var j=0; j<req.param('address2').length;j++){
                var chara = req.param('address2').charAt(j);    
                if ((chara>='a' && chara<='z')||(chara>='A' && chara<='Z')||(chara>='0' && chara <='9')||(chara===' ')){;}
                else{
                    req.flash('message','a problem occured with the creation of the user profile, double check inputs and try again');
                    return res.redirect('/user/create');
                    j=100;
                }
            }
        }
        if ((i=req.param('address1').length) && (j=req.param('address2').length)){tvalueA1=1;}
        if (tvalueA1=1){
            User.create( {
                fName: req.param('fName'),
                lName: req.param('lName'),
                address1: req.param('address1'), 
                address2: req.param('address2'),
                city: req.param('city'),
                state: req.param('state'), 
                zip: req.param('zip')},function userCreated (err1, user){
                if (err1) {
                    req.flash('message','a problem occured with the creation of the user profile, double check inputs and try again');
                    return res.redirect('/user/create');
//                    err1 = validator(user, err1);
//                    res.send(err1);
                }
                else{
                    LoginInfo.create({ 
                        phone: req.param('phone'),
                        email: req.param('email'),
                        password: req.param('password'),               
                        userLoginInfoLink: user.id}, function loginInfoCreate (err2, loginInfo){
                        if (err2){
                            User.destroy(user.id, function(err){
                                req.flash('message','a problem occured with the creation of the login information, double check inputs and try again');
                                return res.redirect('/user/create');
//                                err2 = validator(LoginInfo, err2);
//                                res.send(err2);
                            });
                        }
                        else{
                            req.session.authenticated = true;
                            req.session.User = user;
                            
                            return res.redirect('/user/createCD/'+user.id);
                        }
                    });
                }
            });
        }
    },
    
    createCD: function(req,res,next){
        //finds one record takes passed id and check if user exists, if not return error, if so show it
        User.find({id: req.params['id'], limit: 1})
        .exec(function foundUser(err,user){
            if(err) {return res.serverError(err);}
            res.view({
                user: user[0]
            });
        });
    },
    
    profile: function(req,res,next){
        //finds one record takes passed id and check if user exists, if not return error, if so show it

        
        User.findOne({id: req.params['id']}).exec(function foundUser(err,user){
            if(err) {return res.serverError(err);}
            Type.findOne({userTypeLink: user.id}).exec(function foundLoginInfo(err,typeMain){
                res.view({
                    user: user,
                    typeMain: typeMain
                });
            });
        });
    },
};

