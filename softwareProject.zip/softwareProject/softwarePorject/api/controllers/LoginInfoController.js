/**
 * LoginInfoController
 *
 * @description :: Server-side logic for managing logininfoes
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

